# mavenpom

Simple Maven Projects for testing 
---------------------

This repository contains two small Maven projects intended as examples of how a Maven projects can be setup. They were created to be used in a presentation about Maven.
experimenting

agin
\wer
jjjjjjjjjjjjsjsj
